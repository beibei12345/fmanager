#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>
#include <stdio.h>
#define SCALER 1024
int getFileSize(char* fileno);

int main(){
	printf("%d",getFileSize((char*)"getFileSize.c"));
}

int getFileSize(char* filename){
	struct stat statbuf;
    stat(filename,&statbuf);
    int size=statbuf.st_size;
	return size;
}