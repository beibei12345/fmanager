#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

int main(){
	execl("/usr/bin/mkdir","-p","dir1",NULL);
}