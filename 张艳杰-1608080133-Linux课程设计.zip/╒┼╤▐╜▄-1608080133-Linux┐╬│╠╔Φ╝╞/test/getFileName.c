#include <stdio.h>
#include <string.h>

char *getFileName(const char *path){
	char fileName[50];
	int fileLength=strlen(path);
	int index=fileLength;
	while(index>0 && path[index]!='/'){
		--index;
	}
	strcpy(fileName,*path[index]);
	return fileName;
}

int main(){
	char *testPath="/dir/test.text";
	puts(getFileName(testPath));
}