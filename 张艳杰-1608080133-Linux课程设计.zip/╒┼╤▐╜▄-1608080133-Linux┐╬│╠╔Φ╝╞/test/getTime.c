#include <stdio.h>
#include <time.h>

int main(){
	time_t t;
	struct tm *st;
	time(&t);
	st=localtime(&t);
	printf("当前时间戳：%d",t);
}