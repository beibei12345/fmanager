#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>
#include <signal.h>
#include <sys/param.h>
#include <sys/types.h>
#include <time.h>

#ifndef DEBUG
    //#define DEBUG
#endif // DEBUG

/*
*author:张艳杰
*version:1.0.13
*description:本程序主要用于在Linux系统下批处理文件
*[2019-04-23 13:00:00]comment1:命令解释器最初版本
*[2019-04-23 15:00:00]comment2:将错误进行集中处理
*[2019-05-01 13:00:00]comment3:加入基本拷贝函数
*[2019-05-01 21:00:00]comment4:加入分类型拷贝函数
*[2019-05-03 11:00:00]comment5:修复拷贝时会连同目的目录一起拷贝的bug
*[2019-05-03 12:00:00]comment6:现在可以使用相对目录进行复制了.当前目录..当前目录的父目录
*[2019-05-03 13:00:00]comment7:将最长的目录参数长度和参数长度定义为了宏，可以按需修改
*[2019-05-03 13:00:00]comment8:将打包文件放入临时目录/tmp/fmanager中，防止源目录或者目标目录空间不足造成的错误
*[2019-05-17 23:00:00]comment9:扩展成为了一个框架，以后可以添加功能
*[2019-05-29 23:00:00]comment10:添加单位转换功能
*[2019-06-04 14:00:00]comment11:添加监控文件夹功能
*[2019-06-16 21:00:00]comment12:添加定时备份功能
*[2019-06-19 17:00:00]comment13:添加定时删除功能
*/


#define PEOF          	"---"         		/*结尾符*/
#define BLOCK_SIZE     	102400         		/*复制时块大小*/
#define MAX_DIR_LEN		50					/*最长目录长度*/
#define MAX_INS_LEN		200					/*最长指令长度*/
#define MAX_PARAM_LEN	128					/*单个指令最长长度*/
#define MAX_PARAM_NUM	100					/*参数的最大数量*/
#define MAX_ERR_INFO	50					/*最长错误提示长度*/
#define TMP_DIR			"/tmp/fmanager"		/*临时目录位置*/
#define TMP_DIRD		"/var/fmanagerd"	/*监控目录位置*/
#define TMP_BAKD		"/fmanager.log"		/*备份和删除日志位置*/
#define SCALER 			1024				/*进制换算单位*/


/*定义块*/
char block[BLOCK_SIZE];
/*定义拷贝时使用文件描述符，实际返回的字节数*/
int in,out,nread;
/*定义短选项列表，可扩展*/
const char *l_ins[]={"copy","type","size","name","watch","delay","backup","frequency","time",PEOF};
/*定义长选项列表长度*/
int l_ins_len;
/*定义长选项列表，可扩展*/
const char *s_ins[]={"c","t","s","n","w","d","b","f","x",PEOF};
/*定义短选项列表长度*/
int s_ins_len;
/*定义输入的是何种选项*/
char ins[MAX_INS_LEN];
/*定义选项长度*/
int ins_len;
/*定义参数列表，最长100个参数，每个参数最大128个字符，可以根据情况进行更改*/
char param[MAX_PARAM_NUM][MAX_PARAM_LEN+1];
/*定义实际获取的参数长度*/
int param_len;
/*定义可使用的文件类型*/
const char *types[]={"r","d","b","c","p","l",PEOF};



//函数声明
void init(int argc,char *argv[]);
int get_chararr_len(char **param);
int is_in_charr(char *s,int len,char **dest);
void mkins(int len,char **list);
void sortins();
void error(int error_code,char *info);
void print_err_info(int error_code,char * info);
void copy_block(const char *src,const char *des);
void tar_copy(const char *src_dir,const char *des_dir);
void rm_by_type(const char *dir,const char *type);
void get_abso_path(char *dir);
void copy_with_type(const char *src_dir,const char *des_dir,const char *type);
void copy_with_size(const char *src_dir,const char *des_dir,const char *size_condition,const char *size);
void copy_with_name(const char *src_dir,const char *des_dir,const char *name);
void watchDirectory(const char *dir,int time);
void backupDirectory(const char *src_dir,const char *des_dir,const char *time);
void delayDeleteDirectory(const char *dir,const char *time);
int get_size(const char *size);
void init_daemon(void);
void getFileName(const char *path,char *fileName);
int str2num(char *input);
int power(int x,int y);
time_t getTimestamp(const char *timestr);
time_t getCurrentTime();


int main(int argc,char *argv[])
{
    /*初始化*/
    init(argc,(char**)argv);
    #ifdef DEBUG
        printf("长选项数量：%d，短选项数量：%d\n",l_ins_len,s_ins_len);
    #endif // DEBUG
	
	if(strcmp("ct",ins)==0){
		//fmanager -ct c /dir1 /dir2
		copy_with_type(param[1],param[2],param[0]);
	}else if(strcmp("cs",ins)==0){
		//fmanager -cs gt 200M /dir1 /dir2
		copy_with_size(param[2],param[3],param[0],param[1]);
	}else if(strcmp("cn",ins)==0){
		//fmanager -cn  "^3" /dir1 /dir2
		copy_with_name(param[1],param[2],param[0]);
	}else if(strcmp("tw",ins)==0){
		//fmanager -tw  3 /dir
		watchDirectory(param[1],str2num(param[0]));
	}else if(strcmp("bd",ins)==0){
		//fmanager -bd 12:00 /dir1 /dir2
		backupDirectory(param[1],param[2],param[0]);
	}else if(strcmp("dx",ins)==0){
		//fmanager -dx 12:00 /dir
		delayDeleteDirectory(param[1],param[0]);
	}else{
		error(4," ");
	}
	
	
    return 0;
}
/*初始化各种参数*/
void init(int argc,char *argv[]){
    /*初始化长选项列表长度*/
    l_ins_len=get_chararr_len((char**)l_ins);
    /*初始化长选项列表长度*/
    s_ins_len=get_chararr_len((char**)s_ins);
    /*制作选项串和参数串*/
    mkins(argc,(char**)argv);
}

/*获取长短选项的个数*/
int get_chararr_len(char **param){
    int len=0;
    while(strcmp(param[len++],PEOF)!=0);
    return len-1;
}

/*判断字符串s是否位于dest中，是返回1，否则返回0*/
int is_in_charr(char *s,int len,char **dest){
    int i=0;
    while(strcmp(dest[i++],s)!=0 && i<=len);
    return len!=(i-1)?1:0;
}

/*制作选项串和参数串*/
void mkins(int len,char **list){
    int i;
    for(i=1;i<len;++i){
        if(list[i][0]=='-' && strlen(list[i])==1){
            error(0,"-");
        }
        if(list[i][0]=='-'){/*是*/
            if(list[i][1]=='-'){/*是长选项*/
                /*判断是否是存在的选项*/
                if(is_in_charr(&list[i][2],l_ins_len,(char**)l_ins)){
                    /*取首字母加入选项串中*/
                    ins[ins_len]=list[i][2];
                    ++ins_len;
                }else{
                    error(0,list[i]);
                }
            }else{/*是短选项*/
                int x=1;
                char t[2];
                t[1]='\0';
                while(list[i][x]!='\0'){
                    /*判断是否是存在的选项*/
                    t[0]=list[i][x];
                    if(is_in_charr((char*)t,s_ins_len,(char**)s_ins)){
                        /*加入选项串中*/
                        ins[ins_len]=list[i][x];
                        ++ins_len;
                    }else{
                        char et[3];
                        et[0]='-';et[1]=list[i][x];et[2]='\0';
                        error(0,et);
                    }
                    ++x;
                }
            }
        }else{/*不是选项*/
            /*将参数加入参数列表*/
            strcpy(param[param_len],list[i]);
            ++param_len;
        }
    }
    ins[ins_len]='\0';
    /*对选项串进行排序*/
    sortins();
    #ifdef DEBUG
        printf("选项串长度为%d，选项是：%s\n",ins_len,ins);
        printf("参数表长度为%d\n参数为：\n",param_len);
        for(i=0;i<param_len;++i){
            printf("%d：%s\n",i+1,param[i]);
        }
    #endif // DEBUG
}

/*对选项串进行排序*/
void sortins(){
    int i,j,temp;
    for(i=0;i<ins_len-1;++i){
        for(j=0;j<ins_len-i-1;++j){
            if(ins[j]>ins[j+1]){
                temp=ins[j];
                ins[j]=ins[j+1];
                ins[j+1]=temp;
            }
        }
    }
}

/*用于打印错误信息*/
void print_err_info(int error_code,char *info){
    printf("发生错误！错误码%d：%s\n",error_code,info);
    fflush(stdout);
    exit(-1);
}

/*用于把源文件拷贝给des*/
void copy_block(const char *src,const char *des){
    //打开文件
    if((in=open(src,O_RDONLY))==-1){
        error(1,(char*)src);
    }
    if((out=open(des,O_WRONLY|O_CREAT,S_IRUSR|S_IWUSR))==-1){
        error(2,(char*)des);
    }
    //进行复制操作
    while((nread=read(in,block,BLOCK_SIZE))>0){
        write(out,block,nread);
    }
}

/*根据文件类型进行文件复制*/
void copy_with_type(const char *src_dir,const char *des_dir,const char *type){
    //判断type是否是可用文件类型
    if(!is_in_charr((char*)type,6,(char**)types)){
        error(3,(char*)type);
    }
	char current_dir[MAX_DIR_LEN];	/*用于存储当前工作的目录*/
	/*获取当前工作目录*/
	if(getcwd(current_dir,MAX_DIR_LEN)==NULL){	
		error(5," ");
	}
    DIR *dp=NULL;					/*定义拷贝时使用的文件夹指针*/
    struct dirent *entry=NULL;		/*定义拷贝时使用的文件夹中的项指针*/
    struct stat statbuf;			/*定义拷贝时使用的文件信息结构体*/
	tar_copy(src_dir,TMP_DIR);		/*将源目录所有文件拷贝至临时目录*/
    //扫描临时目录并进行处理
    if((dp=opendir(TMP_DIR))==NULL){
        error(2,(char*)src_dir);
    }
    chdir(TMP_DIR);//进入临时目录
	char rm[MAX_INS_LEN]="rm -rf ";
    switch(type[0]){
        case 'r':
			while((entry=readdir(dp))!=NULL){
				lstat(entry->d_name,&statbuf);
				if(strcmp(".",entry->d_name)==0 || strcmp("..",entry->d_name)==0){
					continue;
				}
				if(!S_ISREG(statbuf.st_mode)){
					strcat(rm,entry->d_name);
					system(rm);
					strcpy(rm,"rm -rf ");
				}
			}break;
        case 'd':
			while((entry=readdir(dp))!=NULL){
				lstat(entry->d_name,&statbuf);
				if(strcmp(".",entry->d_name)==0 || strcmp("..",entry->d_name)==0){
					continue;
				}
				if(!S_ISDIR(statbuf.st_mode)){
					strcat(rm,entry->d_name);
					system(rm);
					strcpy(rm,"rm -rf ");
				}
			}break;
        case 'b':
			while((entry=readdir(dp))!=NULL){
				lstat(entry->d_name,&statbuf);
				if(strcmp(".",entry->d_name)==0 || strcmp("..",entry->d_name)==0){
					continue;
				}
				if(!S_ISBLK(statbuf.st_mode)){
					strcat(rm,entry->d_name);
					system(rm);
					strcpy(rm,"rm -rf ");
				}
			}break;
        case 'c':
			while((entry=readdir(dp))!=NULL){
				lstat(entry->d_name,&statbuf);
				if(strcmp(".",entry->d_name)==0 || strcmp("..",entry->d_name)==0){
					continue;
				}
				if(!S_ISCHR(statbuf.st_mode)){
					strcat(rm,entry->d_name);
					system(rm);
					strcpy(rm,"rm -rf ");
				}
			}break;
        case 'p':
			while((entry=readdir(dp))!=NULL){
				lstat(entry->d_name,&statbuf);
				if(strcmp(".",entry->d_name)==0 || strcmp("..",entry->d_name)==0){
					continue;
				}
				if(!S_ISFIFO(statbuf.st_mode)){
					strcat(rm,entry->d_name);
					system(rm);
					strcpy(rm,"rm -rf ");
				}
			}break;
        case 'l':
			while((entry=readdir(dp))!=NULL){
				lstat(entry->d_name,&statbuf);
				if(strcmp(".",entry->d_name)==0 || strcmp("..",entry->d_name)==0){
					continue;
				}
				if(!S_ISLNK(statbuf.st_mode)){
					strcat(rm,entry->d_name);
					system(rm);
					strcpy(rm,"rm -rf ");
				}
			}break;
		default:break;
    }
    closedir(dp);
	//返回当前工作目录
	chdir(current_dir);
	//将过滤好的文件转运到目标目录
	tar_copy(TMP_DIR,des_dir);
	//删除临时文件
	char tmp[MAX_INS_LEN]="rm -rf ";
	strcat(tmp,TMP_DIR);
	system(tmp);
}

/*定义获取用户输入大小的转换函数*/
int get_size(const char *size){
	int fsize;
	char t[2];t[1]='\0';
	int length=strlen(size);
	char unit=size[length-1];
	sscanf(size,"%d",&fsize);
	switch(unit){
		case 'B':break;
		case 'K':fsize*=SCALER;break;
		case 'M':fsize*=(SCALER*SCALER);break;
		case 'G':fsize*=(SCALER*SCALER*SCALER);break;
		default:
			t[0]=unit;
			error(6,(char*)t);
			break;
	}
	return fsize;
}

/*根据文件大小进行文件复制*/
void copy_with_size(const char *src_dir,const char *des_dir,const char *size_condition,const char *size){
	int fsize=0;
	//判断size_condition是否符合格式{gt|ge|eq|lt|le} number{B|K|M|G}
	//fmanager -cs gt 100M /etc /home
	int inputFileSize=get_size(size);

	char current_dir[MAX_DIR_LEN];	/*用于存储当前工作的目录*/
	/*获取当前工作目录*/
	if(getcwd(current_dir,MAX_DIR_LEN)==NULL){	
		error(5," ");
	}
    DIR *dp=NULL;					/*定义拷贝时使用的文件夹指针*/
    struct dirent *entry=NULL;		/*定义拷贝时使用的文件夹中的项指针*/
    struct stat statbuf;			/*定义拷贝时使用的文件信息结构体*/
	tar_copy(src_dir,TMP_DIR);		/*将源目录所有文件拷贝至临时目录*/
    //扫描临时目录并进行处理
    if((dp=opendir(TMP_DIR))==NULL){
        error(2,(char*)src_dir);
    }
    chdir(TMP_DIR);//进入临时目录
	char rm[MAX_INS_LEN]="rm -rf ";
	
	if(strcmp(size_condition,"gt") == 0){
		while((entry=readdir(dp))!=NULL){
			lstat(entry->d_name,&statbuf);
			if(strcmp(".",entry->d_name)==0 || strcmp("..",entry->d_name)==0){
				continue;
			}
			if(statbuf.st_size <= inputFileSize){
				strcat(rm,entry->d_name);
				system(rm);
				strcpy(rm,"rm -rf ");
			}
		}
	}else if(strcmp(size_condition,"ge") == 0){
		while((entry=readdir(dp))!=NULL){
			lstat(entry->d_name,&statbuf);
			if(strcmp(".",entry->d_name)==0 || strcmp("..",entry->d_name)==0){
				continue;
			}
			if(statbuf.st_size < inputFileSize){
				strcat(rm,entry->d_name);
				system(rm);
				strcpy(rm,"rm -rf ");
			}
		}
	}else if(strcmp(size_condition,"eq") == 0){
		while((entry=readdir(dp))!=NULL){
			lstat(entry->d_name,&statbuf);
			if(strcmp(".",entry->d_name)==0 || strcmp("..",entry->d_name)==0){
				continue;
			}
			if(statbuf.st_size == inputFileSize){
				strcat(rm,entry->d_name);
				system(rm);
				strcpy(rm,"rm -rf ");
			}
		}
	}else if(strcmp(size_condition,"lt") == 0){
		while((entry=readdir(dp))!=NULL){
			lstat(entry->d_name,&statbuf);
			if(strcmp(".",entry->d_name)==0 || strcmp("..",entry->d_name)==0){
				continue;
			}
			if(statbuf.st_size >= inputFileSize){
				strcat(rm,entry->d_name);
				system(rm);
				strcpy(rm,"rm -rf ");
			}
		}
	}else if(strcmp(size_condition,"le") == 0){
		while((entry=readdir(dp))!=NULL){
			lstat(entry->d_name,&statbuf);
			if(strcmp(".",entry->d_name)==0 || strcmp("..",entry->d_name)==0){
				continue;
			}
			if(statbuf.st_size >= inputFileSize){
				strcat(rm,entry->d_name);
				system(rm);
				strcpy(rm,"rm -rf ");
			}
		}
	}
    closedir(dp);
	//返回当前工作目录
	chdir(current_dir);
	//将过滤好的文件转运到目标目录
	tar_copy(TMP_DIR,des_dir);
	//删除临时文件
	char tmp[MAX_INS_LEN]="rm -rf ";
	strcat(tmp,TMP_DIR);
	system(tmp);
}

/*根据文件名称进行文件复制*/
void copy_with_name(const char *src_dir,const char *des_dir,const char *name){
	char current_dir[MAX_DIR_LEN];	/*用于存储当前工作的目录*/
	/*获取当前工作目录*/
	if(getcwd(current_dir,MAX_DIR_LEN)==NULL){	
		error(5," ");
	}
    DIR *dp=NULL;					/*定义拷贝时使用的文件夹指针*/
    struct dirent *entry=NULL;		/*定义拷贝时使用的文件夹中的项指针*/
    struct stat statbuf;			/*定义拷贝时使用的文件信息结构体*/
	tar_copy(src_dir,TMP_DIR);		/*将源目录所有文件拷贝至临时目录*/
    //扫描临时目录并进行处理
    if((dp=opendir(TMP_DIR))==NULL){
        error(2,(char*)src_dir);
    }
    chdir(TMP_DIR);//进入临时目录
	char rm[MAX_INS_LEN]="ls | grep -v '";
	strcat(rm,name);
	strcat(rm,"' | xargs rm -rf");
	system(rm);
	//返回当前工作目录
	chdir(current_dir);
	//将过滤好的文件转运到目标目录
	tar_copy(TMP_DIR,des_dir);
	//删除临时文件
	char tmp[MAX_INS_LEN]="rm -rf ";
	strcat(tmp,TMP_DIR);
	system(tmp);
}


/*打包传输过程*/
void tar_copy(const char *src_dir,const char *des_dir){
	//判断给定位置类型，相对目录则进行转换
	get_abso_path((char*)src_dir);
	//判断给定位置类型，相对目录则进行转换
	get_abso_path((char*)des_dir);
	#ifdef DEBUG
		printf("当前工作的绝对路径是：%s\n",src_dir);
	#endif
	//进入此目录
    chdir(src_dir);
    char s[MAX_DIR_LEN],d[MAX_DIR_LEN];
	char mk[MAX_DIR_LEN]="mkdir -p ";
    strcpy(s,src_dir);
	strcpy(d,des_dir);
    strcat(s,"/tmp.tar");
    strcat(d,"/tmp.tar");
	//将源目录下的所有文件进行打包
    system("tar -cf tmp.tar ./*");
	//制作目标文件夹
    strcat(mk,des_dir);
    system(mk);
    //拷贝到目的文件夹
    copy_block(s,d);
    //删除临时文件
    unlink("tmp.tar");
    //解压
    chdir(des_dir);
    system("tar -xf tmp.tar");
    //删除临时文件
    unlink("tmp.tar");
}

/*获取绝对路径*/
void get_abso_path(char *dir){
	//如果路径第一个字符不是'/'则进行转换
	char t[MAX_DIR_LEN];
	if(getcwd(t,MAX_DIR_LEN)==NULL){
		error(5," ");
	}
	if(dir[0]!='/'){
		if(dir[0]=='.'){
			if(dir[1]=='.'){
				char t2[MAX_DIR_LEN];
				char *d=strrchr(t,'/');
				strncpy(t2,t,d-t);
				strcpy(t,t2);
				strcat(t,&dir[2]);
			}else{
				strcat(t,&dir[1]);
			}
		}else{
			strcat(t,"/");
			strcat(t,dir);
		}
		strcpy(dir,t);
	}
}

//开启一个守护进程
void init_daemon(void){
	pid_t child1,child2;
	int i;
	child1=fork();
	if(child1>0){
		exit(0);
	}else if(child1<0){
		perror("创建子进程失败");
		exit(1);
	}
	
	setsid();
	chdir("/tmp");
	umask(0);
	for(i=0;i<NOFILE;++i){
		close(i);
	}
	return;
}

/*获取文件夹名*/
void getFileName(const char *path,char *fileName){
	int fileLength=strlen(path);
	int index=fileLength-1;
	while(index>-1 && path[index]!='/'){
		--index;
	}
	strcpy(fileName,&path[index+1]);
}

/*字符转数字*/
int str2num(char *input){
    int len=strlen(input);
    int y=len;
    int i;
    int res=0;
    for(i=0;i<len;++i){
        res+=(input[i]-'0')*power(10,y-1);
        --y;
    }
    return res;
}

/*计算x的y次方*/
int power(int x,int y){
	int i;
	int res=1;
	for(i=0;i<y;++i){
		res*=x;
	}
	return res;
}

/*监视某一个文件夹内容，并将日志信息打印进/tmp/fmanagerd/文件夹名称.log*/
void watchDirectory(const char *dir,int time){
	//判断给定位置类型，相对目录则进行转换
	get_abso_path((char*)dir);
	//开启守护进程
	init_daemon();
	
	char fileName[MAX_DIR_LEN];
	getFileName(dir,fileName);
	char output[MAX_INS_LEN];
	strcpy(output,"mkdir -p ");
	strcat(output,TMP_DIRD);
	system(output);
	stpcpy(output,"date>>");
	strcat(output,TMP_DIRD);
	strcat(output,"/");
	strcat(output,fileName);
	strcat(output,".log;ls ");
	strcat(output,dir);
	strcat(output," >>");
	strcat(output,TMP_DIRD);
	strcat(output,"/");
	strcat(output,fileName);
	strcat(output,".log");
	FILE *fp=fopen("yy","w");
	fprintf(fp,"%s",output);
	fclose(fp);
	//进入无限循环，不断向日志输出数据
	while(1){
		system(output);
		sleep(time);
	}
}

//获取当前系统时间，以时间戳形式返回
time_t getCurrentTime(){
    time_t t;
    time(&t);
    return t;
}



//获取目标时间，以时间戳形式返回
time_t getTimestamp(const char *timestr){
    //获取当前系统时间的时间戳，存放在变量t中
    time_t t;
    time(&t);

    //定义要使用的小时和分钟变量
    int hour=0;
    int minute=0;

    //从参数中读取小时和分钟
    sscanf(timestr,"%d:%d",&hour,&minute);

    //获取当前时间的tm结构体
    struct tm *tm_ptr=gmtime(&t);

    //将当前时间的tm结构体改造为目标时间的tm结构体
    tm_ptr->tm_hour=hour;
    tm_ptr->tm_min=minute;
    tm_ptr->tm_sec=0;
    //将目标tm转换为时间戳并返回
    return mktime(tm_ptr);
}

//定时备份某文件夹到目标文件夹，并将日志信息打印进/fmanager.log  */
void backupDirectory(const char *src_dir,const char *des_dir,const char *time){
	char current_dir[MAX_DIR_LEN];	/*用于存储当前工作的目录*/
	/*获取当前工作目录*/
	if(getcwd(current_dir,MAX_DIR_LEN)==NULL){	
		error(5," ");
	}
	
	//printf("%s,%s,%s",src_dir,des_dir,time);
	//开启守护进程
	init_daemon();
	
	//切换回来
	chdir(current_dir);
	
	long targetTimestamp=0;
	long currentTime=0;
	
	while(1){
		targetTimestamp=getTimestamp(time);
		currentTime=getCurrentTime();
		//测试是否到达备份时间，到达则进行文件复制
		if(targetTimestamp == currentTime){
			FILE *fp=fopen(TMP_BAKD,"a");
			fprintf(fp,"%s%s is copied to %s\n",ctime(&currentTime),src_dir,des_dir);
			fclose(fp);
			copy_with_size(src_dir,des_dir,"ge","0B");
		}
		sleep(1);
	}
}

//定时删除某文件夹，并将日志信息打印进/fmanager.log  */
void delayDeleteDirectory(const char *dir,const char *time){
	char current_dir[MAX_DIR_LEN];	/*用于存储当前工作的目录*/
	/*获取当前工作目录*/
	if(getcwd(current_dir,MAX_DIR_LEN)==NULL){	
		error(5," ");
	}
	
	//开启守护进程
	init_daemon();
	
	//切换回来
	chdir(current_dir);
	
	long targetTimestamp=0;
	long currentTime=0;
	
	char del_ins[MAX_INS_LEN];
	
	while(1){
		targetTimestamp=getTimestamp(time);
		currentTime=getCurrentTime();
		//测试是否到达删除时间，到达则进行文件删除
		if(targetTimestamp == currentTime){
			FILE *fp=fopen(TMP_BAKD,"a");
			get_abso_path((char*)dir);
			fprintf(fp,"%s%s is deleted\n",ctime(&currentTime),dir);
			fclose(fp);
			strcpy(del_ins,"rm -rf ");
			strcat(del_ins,dir);
			system(del_ins);
			break;
		}
		sleep(1);
	}
}


/*分类处理错误*/
void error(int error_code,char *info){
    char d_info[MAX_ERR_INFO];
    switch(error_code){
        case 0:
            strcpy(d_info,"非法选项：");
            strcat(d_info,info);
            break;
        case 1:
            strcpy(d_info,"打开文件/目录");
            strcat(d_info,info);
            strcat(d_info,"失败，文件/目录不存在或其他错误！");
            break;
        case 2:
            strcpy(d_info,"创建文件/目录");
            strcat(d_info,info);
            strcat(d_info,"失败，权限不够或者其他错误！");
            break;
        case 3:
            strcpy(d_info,"错误的文件类型：");
            strcat(d_info,info);
            break;
		case 4:
            strcpy(d_info,"无此功能！");
            break;
		case 5:
            strcpy(d_info,"无法获取当前工作目录！");
            break;
		case 6:
            strcpy(d_info,"错误的单位：");
            strcat(d_info,info);
			strcat(d_info,",仅可用（B、K、M、G）！");
            break;
        default:break;
    }
    print_err_info(error_code,d_info);
}



























